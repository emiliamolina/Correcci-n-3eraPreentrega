class Servicios {
    constructor(servicio, precio, invitados){
        this.servicio = servicio;
        this.precio = precio;
        this.invitados = parseInt(invitados)
    }
}

const servicios = [
    {numero: '1', nombre:'Catering', precio: '$7.000'},
    {numero: '2', nombre: 'Decoración', precio:'$1.000'},
    {numero: '3', nombre: 'Musicalización', precio:'$800'},
    {numero: '4', nombre: 'Cotillón y Animación', precio:'$1.300'},
    {numero: '5', nombre: 'Decoración + Cotillón + Animación', precio:'$1.900'},
    {numero: '6', nombre: 'Decoración + Musicalización', precio:'$1.500'},
    {numero: '7', nombre: 'Todos nuestros servicios', precio:'$8.100'}
]


// Primera Parte
function saludar(){
    let name = prompt('¿Cómo te llamas?')
    alert(`Un gusto contactarnos con vos ${name}`)
    
}

function contratar(){
    let resp = prompt('¿Te gustaría contratarnos? \n 1. Si, me encantan sus opciones \n 2. No gracias, por ahora solo quiero conocer los servicios. \n 3. Salir')
    if (resp === '1')
        servicio = prompt('Elige el servicio que querés contratar: \n 1. Catering: $7.000 por persona \n 2. Decoración: $1.000 por persona\n 3. Musicalización: $800 por persona \n 4. Cotillón y Animación: $1.300 por persona \n 5. Decoración + Cotillón + Animación: $1.900 por persona. \n 6. Decoración + Musicalización: $1.500 por persona. \n 6. Todos los servicios: $8.100 por persona.')
    else if (resp === '2')
        alert('Esperamos que pronto vuelvas y cambies de opinión, te dejamos la info')
    else if (resp === '3')
        alert('¡Que tengas un lindo día!')
    else
       alert('No elegiste una opción esperada')

}


function añadirServicio(){
    invitados = prompt('Ingrese la cantidad de invitados: ')
    if (servicio === '1')
    precio = invitados * 7000
    else if (servicio === '2')
    precio = invitados * 1000
    else if (servicio === '3')
    precio = invitados * 800
    else if (servicio === '4')
    precio = invitados * 1300
    else if (servicio === '5')
    precio = invitados * 1900
    else if (servicio === '6')
    precio = invitados * 1500
    else if (servicio === '7')
    precio = invitados * 8100
    
    const nuevoServicio = new Servicios(servicio, precio, invitados)
    carrito.unshift(nuevoServicio)
    alert('Ya añadiste el servicio a tu carrito')

}


function verCarrito(){
    carrito.forEach((producto)=> {
        console.log(`Ya añadió el servicio de ${producto.servicio} para un total de ${producto.invitados} invitados`)
    })
}

let carrito = []

// variables
let servicio
let invitados
let comprar
let segundaCompra
let total
let subtotal
let resp

//programa

saludar()
contratar()


while(servicio === '1'|| servicio ==='2'|| servicio ==='3'|| servicio ==='4'||servicio ==='5'||servicio ==='6'||servicio ==='7'){
    comprar = prompt('¿Quieres contratar el servicio?: \n 1. Sí \n 2. No')
    if(comprar === '1'){
        añadirServicio()
        total = precio
        segundaCompra = prompt('¿Te gustaría sumar otro servicio?: \n 1. Sí \n 2. No')
        while(segundaCompra === '1'){
            servicio = prompt('Elige el servicio que querés agregar: \n 1. Servicio de Catering: $7000 por persona \n 2. Decoración: $1000 por persona \n 3. Musicalización: $800 por persona \n 4. Cotillón y Animación: $1300 por persona')
            añadirServicio()
            total = total + precio
            segundaCompra = prompt('¿Te gustaría sumar otro servicio?: \n 1. Sí \n 2. No')
            continue
            }
        if(segundaCompra === '2'){
            verCarrito()
            break
            }
    }
    if(comprar === '2'){
        break
    }
}
